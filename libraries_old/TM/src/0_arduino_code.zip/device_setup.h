//
// setup this device
//

static const int mySleep = 2 * 1000; // milli sec
// deprecated, because not available in classes: #define TM_VERBOSE 1 // 0 disables all Serial.print() calls
static const bool myVerbose = true;
// #define TM_LOAD_DEVICE_INFLUXDB
// #define TM_LOAD_DEVICE_BME280
#define TM_LOAD_DEVICE_MHZ19
// #define TM_LOAD_DEVICE_OLED_128X32
// #define TM_LOAD_DEVICE_OLED_128X64
#define TM_LOAD_LED_RING
static const char my_device_name[] = "T-ESP32-4";
static const char my_room[] = "Arbeitszimmer";
/*
  Arbeitszimmer
  Kind 1
  Kind 2
  Bad
  Wintergarten
*/
