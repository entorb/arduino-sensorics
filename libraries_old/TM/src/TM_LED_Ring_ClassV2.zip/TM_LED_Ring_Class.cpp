/*
  TM_LED_Ring_Class.cpp - Library for powering WS2812 LED Ring
  */

#include <Adafruit_NeoPixel.h>

#include "TM_Device_Class.h"
#include "TM_LED_Ring_Class.h"

#include "Arduino.h" // for Serial.println()

#define PIN 15
#define NUMPIXELS 8

//Adafruit_NeoPixel my_pixels(NUMPIXELS, PIN, NEO_GRB + NEO_KHZ800);

TM_LED_Ring_Class::TM_LED_Ring_Class() : TM_Device_Class(), my_pixels(NUMPIXELS, PIN, NEO_GRB + NEO_KHZ800)
{
}
