/*
  TM_LED_Ring_Class.h - Library for powering WS2812 LED Ring
*/

#ifndef TM_LED_RING_CLASS_H
#define TM_LED_RING_CLASS_H

#include <Adafruit_NeoPixel.h>

#include "TM_Device_Class.h"

class TM_LED_Ring_Class : public TM_Device_Class
{
public:
  // constructor
  Adafruit_NeoPixel my_pixels;
  TM_LED_Ring_Class();
  // functions

  // variables

private:
};
#endif
