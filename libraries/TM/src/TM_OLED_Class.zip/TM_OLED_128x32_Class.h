/*
  TM_OLED_128x32_Class.h - Library for Connection to OLED Displays
*/

#ifndef TM_OLED_128x32_CLASS_H
#define TM_OLED_128x32_CLASS_H

#include "TM_Device_Class.h"
#include "TM_OLED_Class.h"

class TM_OLED_128x32_Class : public TM_OLED_Class
{
public:
  // constructor
  TM_OLED_128x32_Class();
  // functions

private:
  const static unsigned int px_x = 128;
  const static unsigned int px_y = 32;
  unsigned int barchart_data[px_x]; //TODO: is there a way of defining the array length upon creation of object from class
};

#endif
