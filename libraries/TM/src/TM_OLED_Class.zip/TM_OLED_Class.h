/*
  TM_OLED_Class.h - Library for Connection to OLED Displays
*/

#ifndef TM_OLED_CLASS_H
#define TM_OLED_CLASS_H

#include "TM_Device_Class.h"

#include <U8g2lib.h>

class TM_OLED_Class : public TM_Device_Class
{
public:
  // constructor
  TM_OLED_Class();
  // functions
  void init();
  void drawStr(const char *);
  void drawInt(const unsigned int);
  void drawBarchart(const float);
  void drawAltBarchartOrInt(const float);
  void setBarchartRange(const float, const float);

private:
  U8G2_SSD1306_UNIVISION_F_HW_I2C my_u8g2;
  const static unsigned int px_x;
  const static unsigned int px_y;
  unsigned int barchart_min;
  unsigned int barchart_max;
  unsigned int *barchart_data;    //[px_x]; //TODO: is there a way of defining the array length upon creation of object from class
  bool last_was_barchart = false; // alternate between bar and int chart
};

#endif
